<?php
    header ('Location:'.'views/Manager/home.php');
?>